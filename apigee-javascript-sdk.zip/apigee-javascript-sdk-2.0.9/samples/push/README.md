## Apigee Push Notification Samples Featuring PhoneGap 2.x

The samples here illustrate how you can add push notifications support to an app implemented in HTML5 and JavaScript. The samples use PhoneGap (Apache Cordova) to provide native support for the samples' respective platforms, along with a plugin (included) for push notifications support.

For more specific instructions on running each of the samples, see their readmes.
